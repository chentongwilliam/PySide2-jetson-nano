__version__ = "5.15.10"
__version_info__ = (5, 15, 10, "", "")
