shiboken_library_soversion = str(5.15)

version = "5.15.10"
version_info = (5, 15, 10, "", "")

__build_date__ = '2023-07-11T05:27:21+00:00'




__setup_py_package_version__ = '5.15.10'
